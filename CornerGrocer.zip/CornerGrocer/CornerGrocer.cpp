#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>

using namespace std;

// Class to handle grocery item tracking
class GroceryTracker {
private:
    map<string, int> itemFrequency;

public:
    // Loads data from file into map
    void LoadData(string filename) {
        ifstream inFile(filename);
        string item;
        if (!inFile) {
            cout << "Error opening file: " << filename << endl;
            return;
        }
        while (inFile >> item) {
            itemFrequency[item]++;
        }
        inFile.close();
    }

    // Writes map to backup file
    void SaveToBackupFile(string filename) {
        ofstream outFile(filename);
        for (auto& entry : itemFrequency) {
            outFile << entry.first << " " << entry.second << endl;
        }
        outFile.close();
    }

    // Prints frequency of a specific item
    void PrintItemFrequency(string item) {
        if (itemFrequency.count(item)) {
            cout << item << " appears " << itemFrequency[item] << " times." << endl;
        }
        else {
            cout << item << " was not found in the list." << endl;
        }
    }

    // Prints full frequency list
    void PrintAllItems() {
        for (auto& entry : itemFrequency) {
            cout << entry.first << " " << entry.second << endl;
        }
    }

    // Prints histogram of item frequencies
    void PrintHistogram() {
        for (auto& entry : itemFrequency) {
            cout << left << setw(12) << entry.first << " ";
            for (int i = 0; i < entry.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }
};

// Main function with menu
int main() {
    GroceryTracker tracker;
    tracker.LoadData("CS210_Project_Three_Input_File.txt");
    tracker.SaveToBackupFile("frequency.dat");

    int choice;
    string searchItem;

    do {
        cout << "\nCORNER GROCER - ITEM TRACKER MENU\n";
        cout << "1. Search for an item\n";
        cout << "2. Display frequency of all items\n";
        cout << "3. Display histogram of item frequencies\n";
        cout << "4. Exit\n";
        cout << "Enter your choice (1-4): ";
        cin >> choice;

        // Input validation
        while (cin.fail() || choice < 1 || choice > 4) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Invalid input. Enter a number from 1 to 4: ";
            cin >> choice;
        }

        switch (choice) {
        case 1:
            cout << "Enter item to search for: ";
            cin >> searchItem;
            tracker.PrintItemFrequency(searchItem);
            break;
        case 2:
            tracker.PrintAllItems();
            break;
        case 3:
            tracker.PrintHistogram();
            break;
        case 4:
            cout << "Exiting program. Goodbye!" << endl;
            break;
        }
    } while (choice != 4);

    return 0;
}
